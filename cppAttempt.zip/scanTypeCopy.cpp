#include <iostream>
#include <string>

using namespace std;

std::string charArrayToString(char *text)
{
    std::string s(text);
    return s;
}

enum class TOKENCLASS {BASE, ID, NUMCONST, CHARCONST, STRINGCONST};

class BASE_Token
{
    protected:
        TOKENCLASS tokenClass;
        int lineNumber;
        std::string tokenString;

    public:
        std::string getString()
        {
            return tokenString;
        }

        BASE_Token(int lineNum, char *tokString)
        {
            tokenClass = TOKENCLASS::BASE;
            lineNumber = lineNum;
            tokenString = charArrayToString(tokString);
        }

        BASE_Token(){} // Needed for subclasses
};

class ID_Token : public BASE_Token
{
    public:
        ID_Token(int lineNum, char *tokString)
        {
            tokenClass = TOKENCLASS::ID;
            lineNumber = lineNum;
            tokenString = charArrayToString(tokString);
        }
};

class NUMCONST_Token : public BASE_Token
{
    private:
        int numberValue;

    public:
        NUMCONST_Token(int lineNum, char *tokString)
        {
            tokenClass = TOKENCLASS::NUMCONST;
            lineNumber = lineNum;
            tokenString = charArrayToString(tokString);
        }
};

class CHARCONST_Token : public BASE_Token
{
    private:
        char characterValue;

    public:
        CHARCONST_Token(int lineNum, char *tokString)
        {
            tokenClass = TOKENCLASS::CHARCONST;
            lineNumber = lineNum;
            tokenString = charArrayToString(tokString);
            if(tokenString.length() > 1)
            {
                cout << "WARNING(" << lineNumber << "): character is " << tokenString.length() << " characters long and not a single character: ''" << tokenString << "''.  The first char will be used." << endl;
                tokenString = tokenString[0];
            }
        }
};

class STRINGCONST_Token : public BASE_Token
{
    private:
        std::string stringValue;

    public:
        STRINGCONST_Token(int lineNum, char *tokString)
        {
            tokenClass = TOKENCLASS::STRINGCONST;
            lineNumber = lineNum;
            tokenString = charArrayToString(tokString);
        }
};

void RunTests()
{
    // test that multiple character input to CHARCONST gives an error
    char testCharArray[] = {'E','x','t','r','a','L','o','n','g','A','r','r','a','y','\0'};
    CHARCONST_Token longCharToken = CHARCONST_Token(5, testCharArray);
    cout << "end result of longCharToken: " << longCharToken.getString() << endl;
}

int main()
{
    RunTests();
}